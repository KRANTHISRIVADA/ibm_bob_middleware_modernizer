<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
>

<xsl:output method="xml"/>



<xsl:template match="/">

<xsl:variable name="userName">
            <xsl:value-of select="dp:variable('var://context/input/username')" />
        </xsl:variable>

<xsl:variable name="password">
<xsl:value-of select="dp:variable('var://context/input/password')">
</xsl:value-of>
</xsl:variable>

<xsl:variable name="var_LookUpPassword">

				 <xsl:value-of select="lookupxml/login[@username=$userName]"/>
</xsl:variable>
 
<LoginStatus>
<xsl:choose>
<xsl:when test="$password=$var_LookUpPassword">
<Message>Login has completed sucessfully</Message>
</xsl:when>
<xsl:otherwise>
<Message>Login has failed</Message>
</xsl:otherwise>
</xsl:choose>
</LoginStatus>
</xsl:template>
</xsl:stylesheet>