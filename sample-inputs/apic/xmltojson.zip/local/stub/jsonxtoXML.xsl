<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
>

<xsl:output method="xml"/>



<xsl:template match="/">




<Login>
<username> <xsl:value-of select="json:object/json:object[@name='Login']/json:string[@name='username']" /></username>
<password><xsl:value-of select="json:object/json:object[@name='Login']/json:string[@name='password']"/></password>
</Login>

</xsl:template>
</xsl:stylesheet>