<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
>

<xsl:output method="xml"/>



<xsl:template match="/">




<json:object xsi:schemaLocation="http://www.datapower.com/schemas/json jsonx.xsd"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:json="http://www.ibm.com/xmlns/prod/2009/jsonx"
>
<json:object name="LoginStatus">
<json:string name="Message"><xsl:value-of select="LoginStatus/Message"/></json:string>

</json:object>
</json:object>

</xsl:template>
</xsl:stylesheet>