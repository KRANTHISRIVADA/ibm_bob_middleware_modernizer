<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
>

<xsl:output method="xml"/>

<xsl:template match="/">

<login>
<message>Authentication has completed successfully</message>
<dp:set-variable name="'var://service/mpgw/skip-backside'" value="'1'"/>
</login>

</xsl:template>

</xsl:stylesheet>


	
	