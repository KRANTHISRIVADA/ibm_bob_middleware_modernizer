<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
>

<xsl:output method="xml"/>

<xsl:template match="/">

<xsl:variable name="var_UserName">
			<xsl:value-of select="Login/username" />
		</xsl:variable>
	        <xsl:variable name="var_password">
			<xsl:value-of select="Login/password" />
		</xsl:variable>

<xsl:choose>

  <xsl:when test="$var_UserName = 'admin'">
    <dp:accept/>
  </xsl:when>

  <xsl:otherwise>
    <dp:reject>login has failed</dp:reject>
  </xsl:otherwise>

</xsl:choose>

</xsl:template>

</xsl:stylesheet>
