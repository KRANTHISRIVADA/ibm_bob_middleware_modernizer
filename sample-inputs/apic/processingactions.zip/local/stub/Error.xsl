<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
>

<xsl:output method="xml"/>

<xsl:template match="/">

<xsl:variable name="errorcode" select="dp:variable('var://service/error-code')"/>
<xsl:variable name="errormessage" select="dp:variable('var://service/error-message')"/>
<Login>
<code><xsl:value-of select="$errorcode"/></code>
<message>
<xsl:value-of select="$errormessage"/>
</message>
</Login>

</xsl:template>

</xsl:stylesheet>