<?xml version="1.0"?>
<xsl:stylesheet version="1.0" 
exclude-result-prefixes="dp " 
extension-element-prefixes="dp" 
xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
xmlns:dp="http://www.datapower.com/extensions" 
>

<xsl:output method="xml"/>

<xsl:template match="/">



<signin>
<customername><xsl:value-of select="Login/username" /></customername>
<customerpassword><xsl:value-of select="Login/password" /></customerpassword>
</signin>


</xsl:template>

</xsl:stylesheet>
